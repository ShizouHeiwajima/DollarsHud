Some specific fixes were made for the 1920x1080 resolution.

They can be applied by following the instuctions at the top of this file:

resource/ui/Scoreboard.res