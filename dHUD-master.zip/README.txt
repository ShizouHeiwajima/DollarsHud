Join the Dollars Here
https://discord.gg/EE24Cg4